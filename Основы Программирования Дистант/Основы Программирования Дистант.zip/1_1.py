# №1
# Дано двузначное число. Найти сумму и произведение его цифр.
number = input()
summa = int(number[0]) + int(number[1])
multiplication = int(number[0]) * int(number[1])
print(summa, multiplication)